Pre-requests
XAMPP
Text Editor

Install XAMPP to your PC
Download repo zip
Extract it to C:/xampp/htdocs folder
Run that code by folder name in browser
To the server side server validation need to import database
After connect db reload URL

